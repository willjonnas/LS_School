package com.example.lsbusinessschool

import com.example.lsbusinessschool.model.CourseModel

interface OnCourseListener {
    fun OnClick(course: CourseModel)
}