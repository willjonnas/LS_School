package com.example.lsbusinessschool

import com.example.lsbusinessschool.model.StudentModel

interface OnStudentListener {
    fun OnClick(student: StudentModel)
}